﻿#include <glad/glad.h>
#include <GLFW/glfw3.h>

#include <iostream>

#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#include "camera.h"
#include "mesh.h"

void framebuffer_size_callback(GLFWwindow* window, int width, int height);
void processInput(GLFWwindow* window);

// settings
const unsigned int SCR_WIDTH = 800;
const unsigned int SCR_HEIGHT = 600;

Shader* shader = NULL;
Camera camera(glm::vec3(0, 4, 5), glm::vec3(0, 1, 0), YAW, -40);

// meshes
Mesh* floorMesh = NULL;
Mesh* bookBlockMesh = NULL;
Mesh* bookCoverMesh = NULL;
Mesh* bookSpineMesh = NULL;
Mesh* stopperMesh = NULL;
Mesh* bottleBodyMesh = NULL;
Mesh* bottleNeckMesh = NULL;
Mesh* bottleCapMesh = NULL;
Mesh* bottleTopMesh = NULL;

void setLighting()
{
    // set camera position
    shader->setVec3("viewPos", camera.Position);

    // set parameters for directional light
    shader->setVec3("dirLight.direction", glm::normalize(glm::vec3(1, 0, -1)));
    shader->setVec3("dirLight.ambient", glm::vec3(0.3f));
    shader->setVec3("dirLight.diffuse", glm::vec3(0.3f));
    shader->setVec3("dirLight.specular", glm::vec3(3.0f));

    // set parameters for 4 point lights
    for (int i = 0; i < 4; i++)
    {
        std::string pointLight = "pointLights[" + std::to_string(i) + "].";
        shader->setVec3(pointLight + "position", glm::vec3(cosf(i * 1.0f), 1, sinf(i * 2.0f)));
        shader->setFloat(pointLight + "constant", 1);
        shader->setFloat(pointLight + "linear", 1);
        shader->setFloat(pointLight + "quadratic", 1);
        shader->setVec3(pointLight + "ambient", glm::vec3(0.1f));
        shader->setVec3(pointLight + "diffuse", glm::vec3(0.1f));
        shader->setVec3(pointLight + "specular", glm::vec3(0.1f));
    }

    // set parameters for spot light
    shader->setVec3("spotLight.position", glm::vec3(0, 3, 0));
    shader->setVec3("spotLight.direction", glm::vec3(0, -1, 0));
    shader->setFloat("spotLight.cutOff", 1.0f);
    shader->setFloat("spotLight.outerCutOff", 0.0f);
    shader->setFloat("spotLight.constant", 1);
    shader->setFloat("spotLight.linear", 1);
    shader->setFloat("spotLight.quadratic", 1);
    shader->setVec3("spotLight.ambient", glm::vec3(4.0f));
    shader->setVec3("spotLight.diffuse", glm::vec3(4.0f));
    shader->setVec3("spotLight.specular", glm::vec3(0.0f));

    // set parameters for material
    shader->setInt("material.diffuse", 0);
    shader->setInt("material.specular", 0);
    shader->setFloat("material.shininess", 30);
}

unsigned int loadTexture(const char* filename)
{
    // read image from file
    int width, height;
    stbi_set_flip_vertically_on_load(1);
    unsigned char* image = stbi_load(filename, &width, &height, NULL, 3);

    // check for errors
    if (!image)
    {
        std::cout << "Failed to load texture: " << filename << endl;
        return 0;
    }

    // create new texture
    GLuint textureID;
    glGenTextures(1, &textureID);
    glBindTexture(GL_TEXTURE_2D, textureID);

    // set texture repeating
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);

    // set mipmap filtering
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

    // set image data
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
    glGenerateMipmap(GL_TEXTURE_2D);

    // clean up
    glBindTexture(GL_TEXTURE_2D, 0);
    stbi_image_free(image);
    return textureID;
}

void createTriangle(std::vector<Vertex>& vertices, std::vector<unsigned int>& indices, glm::vec3 p1, glm::vec3 p2, glm::vec3 p3)
{
    // normal vector is cross product of triangle edges
    Vertex vertex;
    vertex.Normal = glm::normalize(glm::cross(p2 - p1, p3 - p1));

    // 1st vertex position and texture coordinates
    vertex.Position = p1;
    vertex.TexCoords = glm::vec2(0, 0);
    vertices.push_back(vertex);

    // 2nd vertex position and texture coordinates
    vertex.Position = p2;
    vertex.TexCoords = glm::vec2(0.3f, 0);
    vertices.push_back(vertex);

    // 3rd vertex position and texture coordinates
    vertex.Position = p3;
    vertex.TexCoords = glm::vec2(0.3f, 0.3f);
    vertices.push_back(vertex);

    // last 3 indices for triangle
    indices.push_back(vertices.size() - 3);
    indices.push_back(vertices.size() - 2);
    indices.push_back(vertices.size() - 1);
}

void createQuad(std::vector<Vertex>& vertices, std::vector<unsigned int>& indices, glm::vec3 p1, glm::vec3 p2, glm::vec3 p3, glm::vec3 p4)
{
    // normal vector is cross product of quad edges
    Vertex vertex;
    vertex.Normal = glm::normalize(glm::cross(p2 - p1, p3 - p1));

    // 1st vertex position and texture coordinates
    vertex.Position = p1;
    vertex.TexCoords = glm::vec2(0, 0);
    vertices.push_back(vertex);

    // 2nd vertex position and texture coordinates
    vertex.Position = p2;
    vertex.TexCoords = glm::vec2(1, 0);
    vertices.push_back(vertex);

    // 3rd vertex position and texture coordinates
    vertex.Position = p3;
    vertex.TexCoords = glm::vec2(0, 1);
    vertices.push_back(vertex);

    // 4th vertex position and texture coordinates
    vertex.Position = p4;
    vertex.TexCoords = glm::vec2(1, 1);
    vertices.push_back(vertex);

    // last 3 indices for 1st triangle
    indices.push_back(vertices.size() - 4);
    indices.push_back(vertices.size() - 3);
    indices.push_back(vertices.size() - 2);

    // last 3 indices for 2nd triangle
    indices.push_back(vertices.size() - 1);
    indices.push_back(vertices.size() - 2);
    indices.push_back(vertices.size() - 3);
}

Mesh* createCubeMesh(float width, float height, float depth, unsigned int textureID)
{
    // mesh data
    std::vector<Vertex> vertices;
    std::vector<unsigned int> indices;

    // for each side
    for (int i = 0; i < 6; i++)
    {
        // side rotation
        glm::mat4 matrix = glm::scale(glm::mat4(1.0f), glm::vec3(width / 2, height / 2, depth / 2)); // front side
        if (i == 1) matrix = glm::rotate(matrix, glm::radians( 90.0f), glm::vec3(0, 1, 0));          // right side
        if (i == 2) matrix = glm::rotate(matrix, glm::radians(180.0f), glm::vec3(0, 1, 0));          // back side
        if (i == 3) matrix = glm::rotate(matrix, glm::radians(-90.0f), glm::vec3(0, 1, 0));          // left side
        if (i == 4) matrix = glm::rotate(matrix, glm::radians( 90.0f), glm::vec3(1, 0, 0));          // bottom side
        if (i == 5) matrix = glm::rotate(matrix, glm::radians(-90.0f), glm::vec3(1, 0, 0));          // top side

        // create square
        glm::vec3 p1 = matrix * glm::vec4(-1, -1, 1, 1);
        glm::vec3 p2 = matrix * glm::vec4( 1, -1, 1, 1);
        glm::vec3 p3 = matrix * glm::vec4(-1,  1, 1, 1);
        glm::vec3 p4 = matrix * glm::vec4( 1,  1, 1, 1);
        createQuad(vertices, indices, p1, p2, p3, p4);
    }

    // set texture
    std::vector<Texture> textures;
    Texture texture;
    texture.id = textureID;
    texture.type = "diffuseTexture";
    textures.push_back(texture);

    return new Mesh(vertices, indices, textures);
}

Mesh* createPrismMesh(float width, float height, float depth, unsigned int textureID)
{
    // mesh data
    std::vector<Vertex> vertices;
    std::vector<unsigned int> indices;

    // prism dimensions
    float w = width / 2;
    float h = height / 2;
    float d = depth / 2;

    // create quads and triangles
    createQuad(vertices, indices, glm::vec3(-w, -h, d), glm::vec3(w, -h, d), glm::vec3(-w, h, d), glm::vec3(w, h, d));   // front side
    createQuad(vertices, indices, glm::vec3(w, -h, d), glm::vec3(w, -h, -d), glm::vec3(w, h, d), glm::vec3(w, h, -d));   // right side
    createQuad(vertices, indices, glm::vec3(w, -h, -d), glm::vec3(-w, -h, d), glm::vec3(w, h, -d), glm::vec3(-w, h, d)); // back side
    createTriangle(vertices, indices, glm::vec3(-w, h, d), glm::vec3(w, h, d), glm::vec3(w, h, -d));                     // top side
    createTriangle(vertices, indices, glm::vec3(-w, -h, d), glm::vec3(w, -h, d), glm::vec3(w, -h, -d));                  // bottom side

    // set texture
    std::vector<Texture> textures;
    Texture texture;
    texture.id = textureID;
    texture.type = "diffuseTexture";
    textures.push_back(texture);

    return new Mesh(vertices, indices, textures);
}

Mesh* createConeMesh(float bottomRadius, float topRadius, float height, unsigned int textureID)
{
    // mesh data
    std::vector<Vertex> vertices;
    std::vector<unsigned int> indices;

    // subdivide cone around its axis
    int n = 50;
    for (int i = 0; i < n; i++)
    {
        // current and next vertices around vertical axis
        for (int j = 0; j < 2; j++)
        {
            // horizontal texture coordinate and angle around vertical axis
            float t = float(i + j) / n;
            float a = glm::radians(t * 360);

            // normal is perpendicular to the cone's surface
            Vertex vertex;
            vertex.Normal = glm::normalize(glm::vec3(-height * cosf(a), bottomRadius - topRadius, height * sinf(a)));

            // bottom vertex
            vertex.Position = glm::vec3(-bottomRadius * cosf(a), 0, bottomRadius * sinf(a));
            vertex.TexCoords = glm::vec2(t, 0.0f);
            vertices.push_back(vertex);

            // top vertex
            vertex.Position = glm::vec3(-topRadius * cosf(a), height, topRadius * sinf(a));
            vertex.TexCoords = glm::vec2(t, 1.0f);
            vertices.push_back(vertex);
        }

        // last 3 indices for 1st triangle
        indices.push_back(vertices.size() - 3);
        indices.push_back(vertices.size() - 4);
        indices.push_back(vertices.size() - 2);

        // last 3 indices for 2nd triangle
        indices.push_back(vertices.size() - 3);
        indices.push_back(vertices.size() - 2);
        indices.push_back(vertices.size() - 1);
    }

    // set texture
    std::vector<Texture> textures;
    Texture texture;
    texture.id = textureID;
    texture.type = "diffuseTexture";
    textures.push_back(texture);

    return new Mesh(vertices, indices, textures);
}

void drawFloor()
{
    glm::mat4 modelMatrix(1.0f);
    modelMatrix = glm::translate(modelMatrix, glm::vec3(0, -0.1f, 0));
    shader->setMat4("model", modelMatrix);
    floorMesh->Draw(*shader);
}

void drawBook()
{
    // draw block
    glm::mat4 modelMatrix(1.0f);
    modelMatrix = glm::translate(modelMatrix, glm::vec3(0, 0.3f, 0));
    shader->setMat4("model", modelMatrix);
    bookBlockMesh->Draw(*shader);

    // draw front cover
    modelMatrix = glm::translate(modelMatrix, glm::vec3(0, 0.3f, -0.02f));
    shader->setMat4("model", modelMatrix);
    bookCoverMesh->Draw(*shader);

    // draw back cover
    modelMatrix = glm::translate(modelMatrix, glm::vec3(0, -0.6f, 0.0f));
    shader->setMat4("model", modelMatrix);
    bookCoverMesh->Draw(*shader);

    // draw spine
    modelMatrix = glm::translate(modelMatrix, glm::vec3(0, 0.3f, 1.08f));
    shader->setMat4("model", modelMatrix);
    bookSpineMesh->Draw(*shader);
}

void drawStopper()
{
    glm::mat4 modelMatrix(1.0f);
    modelMatrix = glm::translate(modelMatrix, glm::vec3(0, 0.9f, -0.6f));
    modelMatrix = glm::rotate(modelMatrix, glm::radians(-20.0f), glm::vec3(0, 1, 0));
    shader->setMat4("model", modelMatrix);
    stopperMesh->Draw(*shader);
}

void drawBottle()
{
    // draw body
    glm::mat4 modelMatrix(1.0f);
    modelMatrix = glm::translate(modelMatrix, glm::vec3(1.8f, 0, 1.4f));
    shader->setMat4("model", modelMatrix);
    shader->setMat4("model", modelMatrix);
    bottleBodyMesh->Draw(*shader);

    // draw neck
    modelMatrix = glm::translate(modelMatrix, glm::vec3(0, 1, 0));
    shader->setMat4("model", modelMatrix);
    bottleNeckMesh->Draw(*shader);

    // draw cap
    modelMatrix = glm::translate(modelMatrix, glm::vec3(0, 0.3f, 0));
    shader->setMat4("model", modelMatrix);
    bottleCapMesh->Draw(*shader);

    // draw top
    modelMatrix = glm::translate(modelMatrix, glm::vec3(0, 0.2f, 0));
    shader->setMat4("model", modelMatrix);
    bottleTopMesh->Draw(*shader);
}

int main()
{
    // glfw: initialize and configure
    // ------------------------------
    glfwInit();
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

#ifdef __APPLE__
    glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
#endif

    // glfw window creation
    // --------------------
    GLFWwindow* window = glfwCreateWindow(SCR_WIDTH, SCR_HEIGHT, "LearnOpenGL", NULL, NULL);
    if (window == NULL)
    {
        std::cout << "Failed to create GLFW window" << std::endl;
        glfwTerminate();
        return -1;
    }
    glfwMakeContextCurrent(window);
    glfwSetFramebufferSizeCallback(window, framebuffer_size_callback);

    // glad: load all OpenGL function pointers
    // ---------------------------------------
    if (!gladLoadGLLoader((GLADloadproc)glfwGetProcAddress))
    {
        std::cout << "Failed to initialize GLAD" << std::endl;
        return -1;
    }

    // load shaders
    shader = new Shader("shaderfiles/6.multiple_lights.vs", "shaderfiles/6.multiple_lights.fs");
    shader->use();

    // load textures
    unsigned int woodTexture = loadTexture("wood.png");
    unsigned int bookBlockTexture = loadTexture("book_block.png");
    unsigned int bookCoverTexture = loadTexture("book_cover.png");
    unsigned int bookSpineTexture = loadTexture("book_spine.png");
    unsigned int stopperTexture = loadTexture("stopper.png");
    unsigned int bottleBodyTexture = loadTexture("bottle_body.png");
    unsigned int bottleNeckTexture = loadTexture("bottle_neck.png");
    unsigned int bottleCapTexture = loadTexture("bottle_cap.png");

    // create meshes
    floorMesh = createCubeMesh(15.0f, 0.2f, 15.0f, woodTexture);
    bookBlockMesh = createCubeMesh(3.1f, 0.6f, 2.1f, bookBlockTexture);
    bookCoverMesh = createCubeMesh(3.2f, 0.04f, 2.2f, bookCoverTexture);
    bookSpineMesh = createCubeMesh(3.2f, 0.56f, 0.04f, bookSpineTexture);
    stopperMesh = createPrismMesh(2.8f, 0.6f, 0.5f, stopperTexture);
    bottleBodyMesh = createConeMesh(0.3f, 0.3f, 1.0f, bottleBodyTexture);
    bottleNeckMesh = createConeMesh(0.3f, 0.2f, 0.3f, bottleNeckTexture);
    bottleCapMesh = createConeMesh(0.2f, 0.2f, 0.2f, bottleCapTexture);
    bottleTopMesh = createConeMesh(0.2f, 0.0f, 0.0f, bottleCapTexture);

    // render loop
    // -----------
    while (!glfwWindowShouldClose(window))
    {
        // input
        // -----
        processInput(window);

        // render
        // ------
        glClearColor(0.2f, 0.3f, 0.3f, 1.0f);
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
        glEnable(GL_DEPTH_TEST);

        // set view matrix
        shader->setMat4("view", camera.GetViewMatrix());

        // get window aspect ratio
        GLint viewport[4];
        glGetIntegerv(GL_VIEWPORT, viewport);
        float aspectRatio = float(viewport[2]) / viewport[3];

        // set perspective projection matrix
        glm::mat4 projectionMatrix = glm::perspective(glm::radians(45.0f), aspectRatio, 0.01f, 100.0f);
        shader->setMat4("projection", projectionMatrix);

        // draw items
        setLighting();
        drawFloor();
        drawBook();
        drawStopper();
        drawBottle();

        // glfw: swap buffers and poll IO events (keys pressed/released, mouse moved etc.)
        // -------------------------------------------------------------------------------
        glfwSwapBuffers(window);
        glfwPollEvents();
    }

    // optional: de-allocate all resources once they've outlived their purpose:
    // ------------------------------------------------------------------------
    delete shader;
    delete floorMesh;
    delete bookBlockMesh;
    delete bookCoverMesh;
    delete bookSpineMesh;
    delete stopperMesh;
    delete bottleBodyMesh;
    delete bottleNeckMesh;
    delete bottleCapMesh;
    delete bottleTopMesh;

    // glfw: terminate, clearing all previously allocated GLFW resources.
    // ------------------------------------------------------------------
    glfwTerminate();
    return 0;
}

// process all input: query GLFW whether relevant keys are pressed/released this frame and react accordingly
// ---------------------------------------------------------------------------------------------------------
void processInput(GLFWwindow* window)
{
    // quit
    if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
        glfwSetWindowShouldClose(window, true);

    // camera movement on cursor or WASD keys
    if (glfwGetKey(window, GLFW_KEY_UP) == GLFW_PRESS || glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS)
        camera.ProcessKeyboard(FORWARD, 0.02f);
    if (glfwGetKey(window, GLFW_KEY_DOWN) == GLFW_PRESS || glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS)
        camera.ProcessKeyboard(BACKWARD, 0.02f);
    if (glfwGetKey(window, GLFW_KEY_LEFT) == GLFW_PRESS || glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS)
        camera.ProcessKeyboard(LEFT, 0.02f);
    if (glfwGetKey(window, GLFW_KEY_RIGHT) == GLFW_PRESS || glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS)
        camera.ProcessKeyboard(RIGHT, 0.02f);

    // get current mouse position
    double xpos, ypos;
    glfwGetCursorPos(window, &xpos, &ypos);
    static double xposLast = xpos, yposLast = ypos;

    // start camera rotation on left mouse button press
    static bool dragging = false;
    if (!dragging && glfwGetMouseButton(window, GLFW_MOUSE_BUTTON_LEFT) == GLFW_PRESS)
    {
        xposLast = xpos;
        yposLast = ypos;
        dragging = true;
    }

    // stop camera rotation on left mouse button release
    if (glfwGetMouseButton(window, GLFW_MOUSE_BUTTON_LEFT) == GLFW_RELEASE)
        dragging = false;

    // camera rotation on left mouse button dragging
    if (dragging)
    {
        camera.ProcessMouseMovement(float(xposLast - xpos), float(ypos - yposLast));
        xposLast = xpos;
        yposLast = ypos;
    }
}

// glfw: whenever the window size changed (by OS or user resize) this callback function executes
// ---------------------------------------------------------------------------------------------
void framebuffer_size_callback(GLFWwindow* window, int width, int height)
{
    // make sure the viewport matches the new window dimensions; note that width and 
    // height will be significantly larger than specified on retina displays.
    glViewport(0, 0, width, height);
}